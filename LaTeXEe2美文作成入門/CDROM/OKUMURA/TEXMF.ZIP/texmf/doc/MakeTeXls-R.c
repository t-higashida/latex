/*
 * This program is completely free to use, to rewrite ...
 *
 * MakeTeXls-R loader
 *
 */

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <process.h>

int main(int ac, char **av)
{
  char cmd[1024];
  int i;
  char buff[256];
  char *p, *fp;

  if(SearchPath(NULL, "MakeTeXls-R", NULL, 256, buff, &fp)) {
    p = buff;
    while(*p) {
      if(*p == '\\') *p = '/';
      p++;
    }
  }
  else {
    fprintf(stderr,"MakeTeXls-R is not found\n");
    exit (1);
  }

  strcpy(cmd, "sh.exe ");
  strcat(cmd, buff);
  for(i=1; i <ac; i++) {
    strcat(cmd, " ");
    strcat(cmd, av[i]);
  }
  i = system(cmd);
  exit(i);
}
