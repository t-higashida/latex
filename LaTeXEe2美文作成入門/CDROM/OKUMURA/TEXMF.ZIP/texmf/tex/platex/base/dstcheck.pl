## 
##  This is file `dstcheck.pl',
##  generated with the docstrip utility.
## 
##  The original source files were:
## 
##  platex.dtx  (with options: `plprog')
##  
##  File: platex.dtx
##  \CharacterTable
##   {Upper-case    \A\B\C\D\E\F\G\H\I\J\K\L\M\N\O\P\Q\R\S\T\U\V\W\X\Y\Z
##    Lower-case    \a\b\c\d\e\f\g\h\i\j\k\l\m\n\o\p\q\r\s\t\u\v\w\x\y\z
##    Digits        \0\1\2\3\4\5\6\7\8\9
##    Exclamation   \!     Double quote  \"     Hash (number) \#
##    Dollar        \$     Percent       \%     Ampersand     \&
##    Acute accent  \'     Left paren    \(     Right paren   \)
##    Asterisk      \*     Plus          \+     Comma         \,
##    Minus         \-     Point         \.     Solidus       \/
##    Colon         \:     Semicolon     \;     Less than     \<
##    Equals        \=     Greater than  \>     Question mark \?
##    Commercial at \@     Left bracket  \[     Backslash     \\
##    Right bracket \]     Circumflex    \^     Underscore    \_
##    Grave accent  \`     Left brace    \{     Vertical bar  \|
##    Right brace   \}     Tilde         \~}
## 
##
## DOCSTRIP �������̊�������̓���q�𒲂ׂ� perl �X�N���v�g
##
push(@dst,"DUMMY"); push(@dst,"000");
push(@env,"DUMMY"); push(@env,"000");
while (<>) {
  if (/^%<\*([^>]+)>/) { # check conditions
    push(@dst,$1);
    push(@dst,$.);
  } elsif (/^%<\/([^>]+)>/) {
    $linenum = pop(@dst);
    $conditions = pop(@dst);
    if ($1 ne $conditions) {
      if ($conditions eq "DUMMY") {
        print "$ARGV: `</$1>' (l.$.) is not started.\n";
        push(@dst,"DUMMY");
        push(@dst,"000");
      } else {
        print "$ARGV: `<*$conditions>' (l.$linenum) is ended ";
        print "by `<*$1>' (l.$.)\n";
      }
    }
  }
  if (/^% *\\begin\{verbatim\}/) { # check environments
    while(<>) {
        last if (/^% *\\end\{verbatim\}/);
    }
  } elsif (/^% *\\begin\{([^{}]+)\}\{(.*)\}/) {
    push(@env,$1);
    push(@env,$.);
  } elsif (/^% *\\begin\{([^{}]+)\}/) {
    push(@env,$1);
    push(@env,$.);
  } elsif (/^% *\\end\{([^{}]+)\}/) {
    $linenum = pop(@env);
    $environment = pop(@env);
    if ($1 ne $environment) {
      if ($environment eq "DUMMY") {
        print "$ARGV: `\\end{$1}' (l.$.) is not started.\n";
        push(@env,"DUMMY");
        push(@env,"000");
      } else {
        print "$ARGV: \\begin{$environement} (l.$linenum) is ended ";
        print "by \\end{$1} (l.$.)\n";
      }
    }
  }
}
$linenum = pop(@dst);
$conditions = pop(@dst);
while ($conditions ne "DUMMY") {
    print "$ARGV: `<*$conditions>' (l.$linenum) is not ended.\n";
    $linenum = pop(@dst);
    $conditions = pop(@dst);
}
$linenum = pop(@env);
$environment = pop(@env);
while ($environment ne "DUMMY") {
    print "$ARGV: `\\begin{$environment}' (l.$linenum) is not ended.\n";
    $linenum = pop(@env);
    $environment = pop(@env);
}
exit;
##  
## 
##  End of file `dstcheck.pl'.
